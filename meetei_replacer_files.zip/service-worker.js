// service-worker.js
const CACHE_VERSION = 'v2';
const CACHE_NAME = `meetei-replacer-${CACHE_VERSION}`;

const PRECACHE_URLS = [
  '/',
  '/index.html',
  '/style.css',
  '/app.js',
  '/dictionary.json',
  '/manifest.json'
];

self.addEventListener('install', (event) => {
  self.skipWaiting();
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(PRECACHE_URLS))
      .catch((err) => { console.warn('SW precache failed:', err); })
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    await self.clients.claim();
    const keys = await caches.keys();
    await Promise.all(keys.map((k) => { if (k !== CACHE_NAME) return caches.delete(k); }));
  })());
});

function isNavigationRequest(request) {
  return request.mode === 'navigate' || (request.method === 'GET' && request.headers.get('accept')?.includes('text/html'));
}

self.addEventListener('fetch', (event) => {
  const req = event.request;
  const url = new URL(req.url);

  if (url.origin !== self.location.origin) return;

  if (url.pathname.endsWith('/app.js') || url.pathname.endsWith('.json')) {
    event.respondWith((async () => {
      try {
        const networkResp = await fetch(req);
        const cache = await caches.open(CACHE_NAME);
        cache.put(req, networkResp.clone()).catch(()=>{});
        return networkResp;
      } catch (err) {
        const cached = await caches.match(req);
        if (cached) return cached;
        if (isNavigationRequest(req)) return caches.match('/index.html');
        return new Response(null, { status: 503, statusText: 'Service Unavailable' });
      }
    })());
    return;
  }

  if (isNavigationRequest(req)) {
    event.respondWith(caches.match(req).then((cached) => cached || fetch(req).catch(()=>caches.match('/index.html'))));
    return;
  }

  if (req.method === 'GET') {
    event.respondWith(caches.match(req).then(async (cached) => {
      if (cached) return cached;
      try {
        const networkResp = await fetch(req);
        const cache = await caches.open(CACHE_NAME);
        cache.put(req, networkResp.clone()).catch(()=>{});
        return networkResp;
      } catch (err) {
        const offlineFallback = await caches.match('/index.html');
        if (offlineFallback && req.headers.get('accept')?.includes('text/html')) return offlineFallback;
        return new Response(null, { status: 503, statusText: 'Service Unavailable' });
      }
    }));
    return;
  }
});

self.addEventListener('message', (event) => {
  if (!event.data) return;
  const { type } = event.data;
  if (type === 'SKIP_WAITING') self.skipWaiting();
});
