// app.js (updated)
// Adds: whole-word-only replacement toggle + chunked merge with progress UI + persistent whole-word preference + auto-merge remote URL on load
const DB_NAME = 'meetei-dict-db';
const DB_STORE = 'dictionary';
const DB_VER = 1;

// UI refs
const inputText = document.getElementById('inputText');
const outputText = document.getElementById('outputText');
const replaceBtn = document.getElementById('replaceBtn');
const clearBtn = document.getElementById('clearBtn');
const copyBtn = document.getElementById('copyBtn');
const downloadOutputBtn = document.getElementById('downloadOutputBtn');

const fileInput = document.getElementById('fileInput');
const mergeBtn = document.getElementById('mergeBtn');
const exportBtn = document.getElementById('exportBtn');
const addFrom = document.getElementById('addFrom');
const addTo = document.getElementById('addTo');
const addPairBtn = document.getElementById('addPairBtn');

const dictCountEl = document.getElementById('dictCount');
const lastSyncedEl = document.getElementById('lastSynced');
const searchKey = document.getElementById('searchKey');
const searchBtn = document.getElementById('searchBtn');
const removeBtn = document.getElementById('removeBtn');
const searchResult = document.getElementById('searchResult');
const helpBtn = document.getElementById('helpBtn');
const helpPanel = document.getElementById('helpPanel');
const syncBtn = document.getElementById('syncBtn');

const wholeWordToggle = document.getElementById('wholeWordToggle');
const mergeProgress = document.getElementById('mergeProgress');

// state
let dictionary = [];
let trie = null;
let lastSynced = null;

// preferences
const PREFS_KEY = 'mmr_prefs';
let prefs = { wholeWordOnly: false, autoMergeUrl: '', lastAutoMerge: null };

function loadPrefs(){ try{ const raw = localStorage.getItem(PREFS_KEY); if(raw) prefs = JSON.parse(raw); }catch(e){/*ignore*/} }
function savePrefs(){ try{ localStorage.setItem(PREFS_KEY, JSON.stringify(prefs)); }catch(e){/*ignore*/} }

// ---------- IndexedDB ----------
function openDb(){ return new Promise((res, rej) => { const r = indexedDB.open(DB_NAME, DB_VER); r.onupgradeneeded = ev => { const db = ev.target.result; if(!db.objectStoreNames.contains(DB_STORE)) db.createObjectStore(DB_STORE, { keyPath: 'id' }); }; r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); }); }
async function saveDictToDb(dictObj){ const db = await openDb(); return new Promise((res, rej) => { const tx = db.transaction(DB_STORE, 'readwrite'); const store = tx.objectStore(DB_STORE); const now = new Date().toISOString(); const obj = { id: 'main', data: dictObj, updatedAt: now }; const putReq = store.put(obj); putReq.onsuccess = () => res(now); putReq.onerror = () => rej(putReq.error); }); }
async function loadDictFromDb(){ const db = await openDb(); return new Promise((res, rej) => { const tx = db.transaction(DB_STORE, 'readonly'); const store = tx.objectStore(DB_STORE); const getReq = store.get('main'); getReq.onsuccess = () => res(getReq.result); getReq.onerror = () => rej(getReq.error); }); }

// ---------- Trie ----------
class TrieNode{ constructor(){ this.children = new Map(); this.value = null; } }
class Trie{ constructor(){ this.root = new TrieNode(); } add(word, val){ let node = this.root; for(const ch of word){ if(!node.children.has(ch)) node.children.set(ch, new TrieNode()); node = node.children.get(ch); } node.value = val; } findFrom(text,pos){ let node = this.root; if(!node) return null; let i = pos; let last = null; while(i<text.length){ const ch = text[i]; node = node.children.get(ch); if(!node) break; i++; if(node.value !== null) last = { replacement: node.value, length: i-pos, matchStart: pos }; } return last; } static fromPairs(pairs){ const t = new Trie(); for(const p of pairs){ if(!p || !p.from) continue; t.add(p.from, p.to ?? ''); } return t; } }

function rebuildTrie(){ trie = Trie.fromPairs(dictionary); }

// ---------- Whole-word helper ----------
const wordCharRegex = /\p{L}|\p{M}|\p{Nd}/u;
function isWordChar(ch){ if(!ch) return false; return wordCharRegex.test(ch); }
function isWholeWordAt(text,pos,len){ const before = pos-1; const after = pos+len; const startChar = text[pos]; const leftIsWord = before >=0 && isWordChar(text[before]); const rightIsWord = after < text.length && isWordChar(text[after]); const matchStartsWithWord = isWordChar(startChar); const lastChar = text[pos+len-1]; const matchEndsWithWord = isWordChar(lastChar); if(matchStartsWithWord && leftIsWord) return false; if(matchEndsWithWord && rightIsWord) return false; return true; }

// ---------- Replacement ----------
function replaceUsingTrie(text, wholeWordOnly = false){ if(!text) return ''; if(!trie) return text; let out=''; let i=0; const n=text.length; while(i<n){ const f = trie.findFrom(text,i); if(f){ if(wholeWordOnly){ if(isWholeWordAt(text,i,f.length)){ out += f.replacement; i += f.length; } else { out += text[i]; i++; } } else { out += f.replacement; i += f.length; } } else { out += text[i]; i++; } } return out; }

// ---------- Merge helpers ----------
function mergePairsQuick(newPairs){ const map = new Map(dictionary.map(p => [p.from, p.to])); for(const p of newPairs) if(p && p.from) map.set(p.from, p.to ?? ''); dictionary = Array.from(map.entries()).map(([from,to])=>({from,to})); rebuildTrie(); }

async function mergePairsChunked(newPairs, {chunkSize=2500, onProgress=()=>{}}={}){ const map = new Map(dictionary.map(p=>[p.from,p.to])); const total = newPairs.length; let processed=0; while(processed<total){ const end = Math.min(processed+chunkSize,total); for(let i=processed;i<end;++i){ const p=newPairs[i]; if(p && p.from) map.set(p.from,p.to ?? ''); } processed = end; onProgress(Math.round((processed/total)*100)); await new Promise(r=>setTimeout(r,10)); } dictionary = Array.from(map.entries()).map(([from,to])=>({from,to})); rebuildTrie(); }

// ---------- UI helpers ----------
function setStatusCount(){ dictCountEl.textContent = `Entries: ${dictionary.length}`; }
function setLastSynced(ts){ lastSynced = ts; lastSyncedEl.textContent = `Last synced: ${ts ? new Date(ts).toLocaleString() : 'never'}`; }

// ---------- Event wiring ----------
replaceBtn.addEventListener('click', ()=>{ replaceBtn.disabled=true; setTimeout(()=>{ try{ const whole = !!(wholeWordToggle && wholeWordToggle.checked); prefs.wholeWordOnly = whole; savePrefs(); outputText.value = replaceUsingTrie(inputText.value, whole); }finally{ replaceBtn.disabled=false; } },10); });
clearBtn.addEventListener('click', ()=>{ inputText.value=''; outputText.value=''; });
copyBtn.addEventListener('click', async ()=>{ try{ await navigator.clipboard.writeText(outputText.value); copyBtn.textContent='Copied!'; setTimeout(()=>copyBtn.textContent='Copy',1200); }catch(e){ alert('Copy failed: '+e); } });
downloadOutputBtn.addEventListener('click', ()=>{ const blob = new Blob([outputText.value], { type:'text/plain;charset=utf-8' }); const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download='replaced_output.txt'; document.body.appendChild(a); a.click(); a.remove(); });

mergeBtn.addEventListener('click', async ()=>{ const files = fileInput.files; if(!files || files.length===0){ alert('Choose a JSON file first'); return; } const txt = await files[0].text(); let json; try{ json = JSON.parse(txt); }catch(e){ alert('Invalid JSON'); return; } const newPairs = json.pairs || []; const LARGE = 5000; try{ if(newPairs.length < LARGE){ mergePairsQuick(newPairs); setStatusCount(); const ts = await saveDictToDb({ pairs: dictionary, meta: json.meta || {} }); setLastSynced(ts); alert(`Merged ${newPairs.length} pairs — total ${dictionary.length}`); } else { mergeProgress.hidden=false; mergeProgress.value=0; await mergePairsChunked(newPairs, { chunkSize: 2500, onProgress: pct => { mergeProgress.value = pct; } }); setStatusCount(); const ts = await saveDictToDb({ pairs: dictionary, meta: json.meta || {} }); setLastSynced(ts); mergeProgress.value=100; setTimeout(()=>{ mergeProgress.hidden=true; mergeProgress.value=0; },800); alert(`Merged ${newPairs.length} pairs — total ${dictionary.length}`); } }catch(e){ mergeProgress.hidden=true; console.warn('Merge failed', e); alert('Merge failed: '+e); } });

exportBtn.addEventListener('click', ()=>{ const exportObj = { pairs: dictionary, meta: { exportedAt: new Date().toISOString() } }; const blob = new Blob([JSON.stringify(exportObj,null,2)], { type:'application/json' }); const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download=`dictionary-export-${new Date().toISOString().slice(0,19).replace(/[:T]/g,'-')}.json`; document.body.appendChild(a); a.click(); a.remove(); });

addPairBtn.addEventListener('click', async ()=>{ const from = addFrom.value.trim(); const to = addTo.value; if(!from){ alert('Provide \"from\"'); return; } const map = new Map(dictionary.map(p=>[p.from,p.to])); map.set(from,to); dictionary = Array.from(map.entries()).map(([from,to])=>({from,to})); rebuildTrie(); setStatusCount(); try{ const ts = await saveDictToDb({ pairs: dictionary, meta: { note: 'single add' } }); setLastSynced(ts); addFrom.value=''; addTo.value=''; }catch(e){ console.warn('Save failed', e); } });

searchBtn.addEventListener('click', ()=>{ const key = searchKey.value.trim(); if(!key){ searchResult.textContent='Enter search value'; return; } const found = dictionary.filter(p=> p.from.includes(key) || (p.to && p.to.includes(key))); searchResult.textContent = JSON.stringify(found.slice(0,200), null, 2); });

removeBtn.addEventListener('click', async ()=>{ const key = searchKey.value.trim(); if(!key){ alert('Enter search query'); return; } const before = dictionary.length; dictionary = dictionary.filter(p => !(p.from.includes(key))); rebuildTrie(); setStatusCount(); try{ const ts = await saveDictToDb({ pairs: dictionary, meta: { note: 'removed matches' } }); setLastSynced(ts); alert(`Removed ${before - dictionary.length} entries`); searchResult.textContent=''; }catch(e){ console.warn('Save failed', e); } });

helpBtn.addEventListener('click', ()=>{ helpPanel.hidden = !helpPanel.hidden; });
syncBtn.addEventListener('click', async ()=>{ try{ const ts = await saveDictToDb({ pairs: dictionary, meta: { note: 'manual sync' } }); setLastSynced(ts); alert('Synced to device'); }catch(e){ alert('Sync failed: '+e); } });

document.addEventListener('keydown',(e)=>{ if((e.ctrlKey||e.metaKey) && e.key==='Enter') replaceBtn.click(); });

// ---------- Initialization ----------
loadPrefs();

// apply saved preference to UI
if(wholeWordToggle) wholeWordToggle.checked = !!prefs.wholeWordOnly;

// auto-merge: if prefs.autoMergeUrl is set and lastAutoMerge > 24h, fetch and merge (simple)
async function tryAutoMerge(){ try{ if(!prefs.autoMergeUrl) return; const last = prefs.lastAutoMerge ? new Date(prefs.lastAutoMerge) : null; const now = new Date(); if(last && (now - last) < 24*60*60*1000) return; const resp = await fetch(prefs.autoMergeUrl); if(!resp.ok) return; const j = await resp.json(); const newPairs = j.pairs || []; if(newPairs.length===0) return; // merge chunked to be safe
  mergeProgress.hidden=false; mergeProgress.value=0; await mergePairsChunked(newPairs, { chunkSize: 2500, onProgress: pct=> { mergeProgress.value=pct; } }); setStatusCount(); const ts = await saveDictToDb({ pairs: dictionary, meta: j.meta || { source: prefs.autoMergeUrl } }); setLastSynced(ts); prefs.lastAutoMerge = new Date().toISOString(); savePrefs(); mergeProgress.value=100; setTimeout(()=>{ mergeProgress.hidden=true; mergeProgress.value=0; },800); console.info('Auto-merged from', prefs.autoMergeUrl); }catch(e){ console.warn('Auto-merge failed', e); mergeProgress.hidden=true; } }

async function init(){ try{ const stored = await loadDictFromDb(); if(stored && stored.data && stored.data.pairs){ dictionary = stored.data.pairs; rebuildTrie(); setStatusCount(); setLastSynced(stored.updatedAt); console.info('Loaded dictionary from IndexedDB:', dictionary.length); } }catch(e){ console.warn('IndexedDB load failed', e); } try{ const resp = await fetch('dictionary.json'); if(resp.ok){ const j = await resp.json(); if(!dictionary || dictionary.length===0){ dictionary = j.pairs || []; rebuildTrie(); setStatusCount(); const ts = await saveDictToDb({ pairs: dictionary, meta: j.meta || {} }); setLastSynced(ts); console.info('Loaded dictionary.json and saved to IndexedDB'); } } }catch(e){ console.warn('Failed to fetch dictionary.json', e); } await tryAutoMerge(); }

init();

// register service worker
if('serviceWorker' in navigator){ window.addEventListener('load', async ()=>{ try{ await navigator.serviceWorker.register('service-worker.js'); console.info('SW registered'); }catch(e){ console.warn('SW register failed', e); } }); }
