Meetei Mayek Replacer - Package
Files included:
- index.html
- style.css
- app.js
- service-worker.js
- manifest.json
- dictionary.json

Usage:
1. Serve this folder over localhost or HTTPS (e.g., npx http-server).
2. Open in browser. On first run it loads dictionary.json and stores in IndexedDB.
3. Use Merge JSON to add daily updates. Use Export to back up.
4. Toggle 'Whole-word only' to restrict replacements to word boundaries.
5. (Optional) Set prefs.autoMergeUrl in localStorage (key 'mmr_prefs') to a JSON URL to auto-merge daily.

